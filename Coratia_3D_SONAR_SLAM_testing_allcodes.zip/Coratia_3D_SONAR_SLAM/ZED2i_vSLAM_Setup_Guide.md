# ZED 2i vSLAM — Full Installation & Run Guide

**Targets:** `zed_rviz` (per-frame live mesh viewer) and `zed_slam_map` (accumulative TSDF SLAM mapper)  
**Platform:** Ubuntu 22.04 LTS (recommended) | ROS 2 Humble | CUDA 12.x | ZED SDK 4.x

---

## Table of Contents

1. [System Requirements](#1-system-requirements)
2. [OS & NVIDIA Driver Setup](#2-os--nvidia-driver-setup)
3. [CUDA Toolkit](#3-cuda-toolkit)
4. [ZED SDK](#4-zed-sdk)
5. [ROS 2 Humble](#5-ros-2-humble)
6. [OpenCV with contrib (ximgproc)](#6-opencv-with-contrib-ximgproc)
7. [Open3D](#7-open3d)
8. [Remaining Dependencies](#8-remaining-dependencies)
9. [Workspace Setup & Build](#9-workspace-setup--build)
10. [Running the Nodes](#10-running-the-nodes)
11. [Tuning Parameters](#11-tuning-parameters)
12. [Output Files](#12-output-files)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| OS | Ubuntu 20.04 | Ubuntu 22.04 LTS |
| CPU | Intel i5 / Ryzen 5 | Intel i7 / Ryzen 7 |
| RAM | 16 GB | 32 GB |
| GPU | NVIDIA GTX 1060 (6 GB VRAM) | RTX 3060 / 3070+ |
| VRAM | 6 GB | 8+ GB |
| USB | USB 3.0 Type-C | USB 3.1 Gen 2 |
| Storage | 20 GB free | 50 GB SSD |
| NVIDIA Driver | ≥ 525 | ≥ 545 |
| CUDA | 11.8 | 12.x |

> **Note:** The TSDF volume in `zed_slam_map` uses ~300 MB VRAM at 4 cm voxel resolution with `BLOCK_COUNT=40000`. A dedicated NVIDIA GPU is strongly recommended; a CPU fallback path exists but is significantly slower.

---

## 2. OS & NVIDIA Driver Setup

### 2.1 Update the system

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y build-essential cmake git wget curl pkg-config \
    libssl-dev libffi-dev python3-pip
```

### 2.2 Install NVIDIA driver

```bash
# Check what's available
ubuntu-drivers devices

# Install recommended driver (replace 545 with your version)
sudo apt install -y nvidia-driver-545

# Reboot
sudo reboot
```

### 2.3 Verify driver

```bash
nvidia-smi
# Should show driver version, CUDA version, and GPU name
```

---

## 3. CUDA Toolkit

Install CUDA **matching your driver version** from the [NVIDIA CUDA archive](https://developer.nvidia.com/cuda-downloads).

```bash
# Example: CUDA 12.2 on Ubuntu 22.04
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb
sudo dpkg -i cuda-keyring_1.1-1_all.deb
sudo apt update
sudo apt install -y cuda-toolkit-12-2

# Add to PATH (add these to ~/.bashrc)
echo 'export PATH=/usr/local/cuda/bin:$PATH' >> ~/.bashrc
echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> ~/.bashrc
source ~/.bashrc
```

### Verify

```bash
nvcc --version
# Should print: Cuda compilation tools, release 12.x
```

---

## 4. ZED SDK

The ZED 2i requires **ZED SDK version 4.x** (the CMakeLists uses `find_package(ZED 3 REQUIRED)` — SDK 4.x is backward compatible with this find script).

### 4.1 Download

Go to [stereolabs.com/developers/release](https://www.stereolabs.com/developers/release/) and download the installer for your CUDA version, or use:

```bash
# Example: ZED SDK 4.1 for CUDA 12.x Ubuntu 22
wget https://download.stereolabs.com/zedsdk/4.1/cu121/ubuntu22 -O ZED_SDK_Ubuntu22_cuda12.1_v4.1.run
chmod +x ZED_SDK_Ubuntu22_cuda12.1_v4.1.run
sudo ./ZED_SDK_Ubuntu22_cuda12.1_v4.1.run
```

During installation, accept the license, and when asked about tools/Python API — accept both.

### 4.2 Verify

```bash
# Run the built-in diagnostic tool
/usr/local/zed/tools/ZED_Diagnostic

# Or run the depth viewer
/usr/local/zed/tools/ZED_Depth_Viewer
```

Plug in your ZED 2i via USB 3 before running.

### 4.3 USB permissions (udev rules)

The SDK installer usually adds udev rules. If you get permission errors:

```bash
sudo cp /usr/local/zed/resources/99-slabs.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
# Log out and back in, or add your user to the video group:
sudo usermod -aG video $USER
```

---

## 5. ROS 2 Humble

### 5.1 Set locale

```bash
sudo apt install -y locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8
```

### 5.2 Add ROS 2 apt repository

```bash
sudo apt install -y software-properties-common
sudo add-apt-repository universe
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
    -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
    http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
    | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
```

### 5.3 Install ROS 2 Humble Desktop

```bash
sudo apt install -y ros-humble-desktop
```

### 5.4 Install build tools

```bash
sudo apt install -y python3-colcon-common-extensions python3-rosdep \
    python3-vcstool ros-humble-rmw-cyclonedds-cpp
sudo rosdep init
rosdep update
```

### 5.5 Source ROS 2 in every terminal (add to ~/.bashrc)

```bash
echo 'source /opt/ros/humble/setup.bash' >> ~/.bashrc
source ~/.bashrc
```

---

## 6. OpenCV with contrib (ximgproc)

The code uses `cv::ximgproc::DisparityWLSFilter` which is in `opencv_contrib`. You need to build from source (the apt package does not include contrib).

### 6.1 Install build dependencies

```bash
sudo apt install -y \
    libgtk-3-dev libavcodec-dev libavformat-dev libswscale-dev \
    libv4l-dev libxvidcore-dev libx264-dev libjpeg-dev libpng-dev \
    libtiff-dev gfortran openexr libatlas-base-dev libtbb2 libtbb-dev \
    libdc1394-dev libopenexr-dev libgstreamer-plugins-base1.0-dev \
    libgstreamer1.0-dev python3-dev python3-numpy
```

### 6.2 Clone and build

```bash
cd ~/
git clone https://github.com/opencv/opencv.git --branch 4.8.0 --depth 1
git clone https://github.com/opencv/opencv_contrib.git --branch 4.8.0 --depth 1

mkdir opencv/build && cd opencv/build

cmake .. \
  -DCMAKE_BUILD_TYPE=Release \
  -DOPENCV_EXTRA_MODULES_PATH=~/opencv_contrib/modules \
  -DWITH_CUDA=ON \
  -DCUDA_ARCH_BIN="7.5 8.6 8.9" \
  -DWITH_TBB=ON \
  -DWITH_GTK=ON \
  -DBUILD_opencv_python3=ON \
  -DCMAKE_INSTALL_PREFIX=/usr/local \
  -DBUILD_EXAMPLES=OFF \
  -DBUILD_TESTS=OFF

# Build with all CPU cores (this takes ~20-40 minutes)
make -j$(nproc)
sudo make install
sudo ldconfig
```

> **CUDA_ARCH_BIN:** Set this to your GPU's compute capability.
> - RTX 30xx → `8.6`
> - RTX 40xx → `8.9`
> - GTX 10xx / RTX 20xx → `7.5` or `6.1`
> Check yours at [developer.nvidia.com/cuda-gpus](https://developer.nvidia.com/cuda-gpus)

### 6.3 Verify

```bash
python3 -c "import cv2; print(cv2.__version__); print(cv2.ximgproc)"
# Should print 4.8.0 and <module 'cv2.ximgproc'>
```

---

## 7. Open3D

`zed_slam_map` uses Open3D's TSDF `VoxelBlockGrid` and tensor API. Install from pip (easiest) or build from source.

### Option A — pip (recommended for most users)

```bash
pip3 install open3d==0.18.0
```

Then create a CMake find-script pointer:

```bash
# Find where pip installed it
python3 -c "import open3d; print(open3d.__file__)"
# e.g. /usr/local/lib/python3.10/dist-packages/open3d/__init__.py

# Set Open3D_DIR for CMake
export Open3D_DIR=$(python3 -c "import open3d; import os; print(os.path.join(os.path.dirname(open3d.__file__), 'CMake'))")
echo "export Open3D_DIR=$Open3D_DIR" >> ~/.bashrc
```

### Option B — build from source (for full CUDA tensor support)

```bash
sudo apt install -y libeigen3-dev libglfw3-dev libglew-dev

git clone https://github.com/isl-org/Open3D.git --branch v0.18.0 --depth 1
mkdir Open3D/build && cd Open3D/build

cmake .. \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_CUDA_MODULE=ON \
  -DCUDA_ARCH="8.6" \
  -DBUILD_SHARED_LIBS=ON \
  -DCMAKE_INSTALL_PREFIX=/usr/local

make -j$(nproc)   # takes ~60 min
sudo make install
sudo ldconfig
```

---

## 8. Remaining Dependencies

```bash
# Eigen3
sudo apt install -y libeigen3-dev

# GLFW + OpenGL + GLEW
sudo apt install -y libglfw3-dev libglew-dev libgl1-mesa-dev \
    libglu1-mesa-dev freeglut3-dev

# PCL (Point Cloud Library)
sudo apt install -y libpcl-dev

# Nav msgs (for zed_slam_map ROS topics)
sudo apt install -y ros-humble-nav-msgs ros-humble-geometry-msgs \
    ros-humble-sensor-msgs ros-humble-visualization-msgs
```

---

## 9. Workspace Setup & Build

### 9.1 Create ROS 2 workspace

```bash
mkdir -p ~/ros2_ws/src/zed_rviz/src
cd ~/ros2_ws/src/zed_rviz
```

### 9.2 Copy your source files

```bash
# Place your files:
#   src/zed_rviz.cpp
#   src/zed_slam_map.cpp
#   CMakeLists.txt
#   package.xml   ← create this (see below)
```

### 9.3 Create package.xml

Create `~/ros2_ws/src/zed_rviz/package.xml`:

```xml
<?xml version="1.0"?>
<?xml-model href="http://download.ros.org/schema/package_format3.xsd" schematypens="http://www.w3.org/2001/XMLSchema"?>
<package format="3">
  <name>zed_rviz</name>
  <version>1.0.0</version>
  <description>ZED 2i live mesh viewer and vSLAM spatial mapper</description>
  <maintainer email="you@example.com">Your Name</maintainer>
  <license>MIT</license>

  <buildtool_depend>ament_cmake</buildtool_depend>

  <depend>rclcpp</depend>
  <depend>sensor_msgs</depend>
  <depend>visualization_msgs</depend>
  <depend>geometry_msgs</depend>
  <depend>std_msgs</depend>
  <depend>nav_msgs</depend>

  <export>
    <build_type>ament_cmake</build_type>
  </export>
</package>
```

### 9.4 Build

```bash
cd ~/ros2_ws

# Source ROS 2
source /opt/ros/humble/setup.bash

# Tell CMake where Open3D is (if using pip install)
export Open3D_DIR=$(python3 -c "import open3d, os; print(os.path.join(os.path.dirname(open3d.__file__), 'CMake'))")

# Build (Release mode for performance)
colcon build --packages-select zed_rviz \
    --cmake-args -DCMAKE_BUILD_TYPE=Release \
    --parallel-workers $(nproc)
```

If you encounter CMake policy warnings, they are suppressed by the `cmake_policy` lines already in CMakeLists.txt — this is expected.

### 9.5 Source the workspace

```bash
source ~/ros2_ws/install/setup.bash
# Add to ~/.bashrc so you don't need to repeat this:
echo 'source ~/ros2_ws/install/setup.bash' >> ~/.bashrc
```

---

## 10. Running the Nodes

### Plug in the ZED 2i

Connect the camera via the USB 3.0 Type-C cable. Verify it is detected:

```bash
lsusb | grep -i stereo
# Should show: Stereolabs ZED 2i
```

### 10.1 zed_rviz — Per-frame live mesh viewer

This node shows a **real-time 3D mesh of the current camera view** only. No map accumulation. Good for checking depth quality and calibration.

```bash
# Terminal 1: Run the node
ros2 run zed_rviz zed_rviz
```

A GLFW window opens showing the live depth mesh. OpenCV windows show `Rectified Left`, `Disparity (WLS)`, and `Depth colour` previews.

**Controls:**
- Left mouse drag → orbit
- Scroll wheel → zoom in/out

**ROS Topics published:**
- `/zed/point_cloud` — PointCloud2
- `/zed/mesh_marker` — visualization_msgs/Marker (LINE_LIST triangles)

### 10.2 zed_slam_map — Accumulative vSLAM mapper

This node **builds a growing global map** as you move the camera. Uses ZED SDK positional tracking + Open3D TSDF volume fusion.

```bash
# Terminal 1: Run the SLAM node
ros2 run zed_rviz zed_slam_map
```

A GLFW window opens showing the accumulated mesh growing over time. A coloured trajectory line shows camera path.

**Controls:**
- Left mouse drag → orbit
- Scroll wheel → zoom
- `W/S` → pan forward/back
- `A/D` → pan left/right
- `Q/E` → pan up/down

**ROS Topics published:**
- `/zed/point_cloud` — PointCloud2
- `/zed/odom` — nav_msgs/Odometry
- `/zed/pose` — geometry_msgs/PoseStamped

**On shutdown** (Ctrl+C), the node automatically saves:
- `final_map.ply` — coloured point cloud
- `final_map_mesh.ply` — triangle mesh
- `final_map.csv` — CloudCompare-compatible coloured point cloud

### 10.3 Viewing in RViz2 (optional)

```bash
# Terminal 2: Launch RViz
ros2 run rviz2 rviz2
```

In RViz:
1. Set **Fixed Frame** to `zed_left_camera`
2. Add → By Topic → `/zed/point_cloud` → PointCloud2
3. Add → By Topic → `/zed/mesh_marker` → Marker (for zed_rviz)
4. Add → By Topic → `/zed/pose` → PoseStamped (for zed_slam_map)

---

## 11. Tuning Parameters

All tunable constants are at the top of each source file under the `TUNE` section.

### zed_slam_map.cpp — Map Quality vs. Performance

| Parameter | Default | Effect |
|-----------|---------|--------|
| `VOXEL_SIZE` | `0.04f` (4 cm) | Smaller = finer detail, more VRAM. Try `0.02` for 2 cm indoors |
| `TSDF_TRUNC` | `0.16f` | Keep at 4× `VOXEL_SIZE` |
| `BLOCK_COUNT` | `40000` | ~300 MB VRAM. Reduce if OOM; increase for larger spaces |
| `KEYFRAME_EVERY` | `3` | Integrate every N frames. Lower = denser but slower |
| `EXTRACT_EVERY` | `1` | Re-mesh every N keyframes. Increase (e.g., `5`) to reduce CPU load |
| `DEPTH_MIN` | `0.3f` | Minimum depth in metres |
| `DEPTH_MAX` | `8.0f` | Maximum depth in metres |
| `PC_STEP` | `3` | Point cloud downsampling: higher = fewer points published |

### zed_rviz.cpp

| Parameter | Default | Effect |
|-----------|---------|--------|
| `PC_STEP` | `8` | Point cloud publish density |
| `z_min/z_max` in `buildMesh()` | `0.3/8.0` | Depth range for mesh |

### Camera resolution

Both nodes open the ZED at `HD720` (1280×720) @ 30 fps. To change, edit the `InitParameters` in the constructor:

```cpp
ip.camera_resolution = RESOLUTION::HD1080;  // 1920×1080, heavier
ip.camera_fps        = 15;                   // lower fps for slower systems
```

---

## 12. Output Files

### zed_rviz
- `pointcloud_frame_N.csv` — saved every 10 frames in the working directory. Format: `X,Y,Z,R,G,B`

### zed_slam_map (on node shutdown)
- `final_map.ply` — coloured point cloud (Open3D PointCloud format)
- `final_map_mesh.ply` — triangle mesh (Open3D TriangleMesh format)
- `final_map.csv` — columns: `X,Y,Z,R_255,G_255,B_255,R_f,G_f,B_f`

### Opening in CloudCompare

1. File → Open → `final_map.csv`
2. In the ASCII import wizard: tick "Contains header", separator = comma
3. Assign: columns 1–3 as X/Y/Z, columns 4–6 as R/G/B (0–255 int)
4. The float columns (7–9) are for reference; CloudCompare uses the int ones

---

## 13. Troubleshooting

### ZED camera not found
```
ZED open failed
```
- Check USB 3.0 connection (blue port, not USB 2.0)
- Run `lsusb` to confirm detection
- Try: `sudo /usr/local/zed/tools/ZED_Diagnostic`
- Reload udev rules: `sudo udevadm control --reload-rules && sudo udevadm trigger`

### GLFW window fails to open
```
GLFW init failed  or  GLFW window failed
```
- Ensure a display is connected. On headless servers, set `export DISPLAY=:0`
- Install: `sudo apt install -y libglfw3 libglew2.2 mesa-utils`
- Test OpenGL: `glxinfo | grep "OpenGL version"`

### TSDF falls back to CPU
```
CUDA TSDF unavailable — CPU fallback
```
- CPU fallback works but is ~10× slower
- Check CUDA: `nvidia-smi` and `nvcc --version`
- Verify Open3D was built with CUDA: `python3 -c "import open3d; print(open3d.core.cuda.is_available())"`
- Rebuild Open3D from source with `-DBUILD_CUDA_MODULE=ON`

### OpenCV ximgproc not found (build error)
```
fatal error: opencv2/ximgproc.hpp: No such file or directory
```
- You installed OpenCV from apt without contrib. You must build from source (see Section 6).
- Verify: `python3 -c "import cv2; print(cv2.ximgproc)"`

### Open3D CMake not found
```
Could not find a package configuration file provided by "Open3D"
```
- Set `Open3D_DIR` before building:
```bash
export Open3D_DIR=$(python3 -c "import open3d, os; print(os.path.join(os.path.dirname(open3d.__file__), 'CMake'))")
colcon build --cmake-args -DOpen3D_DIR=$Open3D_DIR ...
```

### Positional tracking not OK / map drifts badly
- Ensure the ZED 2i has IMU fusion enabled (it does by default in the code: `ptp.enable_imu_fusion = true`)
- Move the camera slowly and smoothly — fast motion causes tracking loss
- Ensure good lighting and textured environments; blank white walls cause tracking failure
- If tracking is lost, restart the node (there is no recovery in the current code)

### High CPU / frame drops
- Increase `KEYFRAME_EVERY` from `3` to `5` or `10`
- Increase `EXTRACT_EVERY` from `1` to `5` (mesh extracted less often)
- Increase `PC_STEP` from `3` to `6` (fewer points published)
- Lower camera resolution to `VGA` (672×376)

### Out of VRAM during TSDF
- Reduce `BLOCK_COUNT` (e.g., from `40000` to `20000`) — halves VRAM to ~150 MB
- Increase `VOXEL_SIZE` (e.g., `0.06f` = 6 cm) — each block covers more volume
- Both together allow mapping larger areas with the same memory budget

---

## Quick-Reference: Full Install Order

```
1. Ubuntu 22.04 + NVIDIA driver
2. CUDA Toolkit 12.x
3. ZED SDK 4.x
4. ROS 2 Humble
5. OpenCV 4.8 with contrib (from source)
6. Open3D 0.18 (pip or source)
7. Eigen3, GLFW, GLEW, PCL (apt)
8. Create workspace, copy files, colcon build
9. source install/setup.bash
10. ros2 run zed_rviz zed_slam_map
```
