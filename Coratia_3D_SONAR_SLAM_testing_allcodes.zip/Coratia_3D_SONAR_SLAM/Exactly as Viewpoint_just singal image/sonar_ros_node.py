#!/usr/bin/env python3
"""
Oculus M750d ROS2 node — ViewPoint-style fan image.
Fixes:
  1) Lag → rendering runs in separate thread, ROS spin never blocks
  2) Contrast → proper min..max stretch (not just /max)
  3) Threshold auto-adjusted based on actual data range
"""
import rclpy
from rclpy.node import Node
import numpy as np
import threading
import queue

from sensor_msgs.msg import PointCloud2, PointField, LaserScan, Image
from std_msgs.msg import Header
from oculus_driver.oculus_driver import OculusDriver, SonarPing

# ── Oculus ViewPoint default palette (warm gold, from SDK palettes.bmp) ──────
_PAL_RAW = [
    (2,1,0),(4,2,0),(6,4,0),(8,5,0),(10,6,0),(12,7,0),(14,9,0),(15,10,0),(17,11,0),(19,12,0),(21,14,0),(23,15,0),(25,16,0),(27,17,0),(29,18,0),(31,20,0),
    (33,21,0),(35,22,0),(37,23,0),(39,25,0),(41,26,0),(43,27,0),(45,28,0),(46,29,0),(48,31,0),(50,32,0),(52,33,0),(54,34,0),(56,36,0),(58,37,0),(60,38,0),(62,39,0),
    (64,41,0),(66,42,0),(68,43,0),(70,44,0),(72,45,0),(74,47,0),(76,48,0),(77,49,0),(79,50,0),(81,52,0),(83,53,0),(85,54,0),(87,55,0),(89,57,0),(91,58,0),(93,59,0),
    (95,60,0),(97,61,0),(99,63,0),(101,64,0),(103,65,0),(105,66,0),(107,68,0),(108,69,0),(110,70,0),(112,71,0),(114,72,0),(116,74,0),(118,75,0),(120,76,0),(122,77,0),(124,79,0),
    (126,80,0),(128,81,0),(130,82,0),(131,83,0),(133,85,0),(135,86,0),(137,87,0),(139,88,0),(141,89,0),(143,91,0),(145,92,0),(146,93,0),(148,94,0),(150,95,0),(152,97,0),(154,98,0),
    (156,99,0),(158,100,0),(160,101,0),(161,103,0),(163,104,0),(165,105,0),(167,106,0),(169,107,0),(171,109,0),(173,110,0),(175,111,0),(176,112,0),(178,113,0),(180,115,0),(182,116,0),(184,117,0),
    (186,118,0),(188,119,0),(190,120,0),(191,122,0),(193,123,0),(195,124,0),(197,125,0),(199,126,0),(201,128,0),(203,129,0),(205,130,0),(206,131,0),(208,132,0),(210,134,0),(212,135,0),(214,136,0),
    (216,137,0),(218,138,0),(220,140,0),(221,141,0),(223,142,0),(225,143,0),(227,144,0),(229,146,0),(231,147,0),(233,148,0),(235,149,0),(236,150,0),(238,152,0),(240,153,0),(242,154,0),(242,157,6),
    (242,157,6),(243,159,12),(243,162,19),(244,165,25),(244,167,31),(244,170,37),(245,173,43),(245,176,49),(246,178,56),(246,181,62),(246,184,68),(247,186,74),(247,189,80),(248,192,86),(248,194,93),(248,197,99),
    (249,200,105),(249,203,111),(249,205,117),(250,208,124),(250,211,130),(251,213,136),(251,216,142),(251,219,148),(252,221,154),(252,224,161),(253,227,167),(253,229,173),(253,232,179),(254,235,185),(254,238,192),(255,240,198),
    (255,243,204),(255,243,205),(255,243,205),(255,243,206),(255,244,206),(255,244,207),(255,244,208),(255,244,208),(255,244,209),(255,244,209),(255,244,210),(255,244,210),(255,245,211),(255,245,212),(255,245,212),(255,245,213),
    (255,245,213),(255,245,214),(255,245,215),(255,245,215),(255,246,216),(255,246,216),(255,246,217),(255,246,218),(255,246,218),(255,246,219),(255,246,219),(255,247,220),(255,247,221),(255,247,221),(255,247,222),(255,247,222),
    (255,247,223),(255,247,223),(255,247,224),(255,248,224),(255,248,225),(255,248,225),(255,248,226),(255,248,226),(255,248,227),(255,248,227),(255,248,228),(255,249,228),(255,249,229),(255,249,230),(255,249,230),(255,249,231),
    (255,249,231),(255,249,232),(255,249,232),(255,250,233),(255,250,233),(255,250,234),(255,250,234),(255,250,235),(255,250,235),(255,250,236),(255,250,236),(255,251,237),(255,251,237),(255,251,238),(255,251,238),(255,251,239),
    (255,251,239),(255,251,240),(255,251,240),(255,252,241),(255,252,241),(255,252,242),(255,252,243),(255,252,243),(255,252,244),(255,252,244),(255,252,245),(255,253,245),(255,253,246),(255,253,246),(255,253,247),(255,253,247),
    (255,253,248),(255,253,248),(255,253,249),(255,254,249),(255,254,250),(255,254,250),(255,254,251),(255,254,251),(255,254,252),(255,254,252),(255,254,253),(255,255,253),(255,255,254),(255,255,254),(255,255,255),(255,255,255),
]
PALETTE = np.array(_PAL_RAW, dtype=np.uint8)  # shape (256, 3)


# ─────────────────────────────────────────────────────────────────────────────
class FanRenderer:
    """
    Pre-builds a pixel→(range_idx, beam_idx) LUT once per sonar config,
    then renders each ping in pure NumPy — zero Python loops at render time.
    """

    def __init__(self, out_w: int, out_h: int):
        self.out_w  = out_w
        self.out_h  = out_h
        self._cfg   = None   # last known config tuple
        self._ri    = None   # range index per in-fan pixel
        self._bi    = None   # beam  index per in-fan pixel
        self._flat_mask = None   # flat bool (out_h*out_w,)

    # ── LUT build ─────────────────────────────────────────────────────────
    def _build_lut(self, ping: SonarPing):
        W, H = self.out_w, self.out_h
        brg_min   = float(ping.bearings_deg[0])
        brg_max   = float(ping.bearings_deg[-1])
        max_range = ping.n_ranges * ping.range_resolution

        cols = np.arange(W, dtype=np.float32)
        rows = np.arange(H, dtype=np.float32)
        C, R = np.meshgrid(cols, rows)   # (H, W)

        # Sonar apex at bottom-centre of image
        ox    = W / 2.0
        oy    = float(H)
        scale = oy / max_range           # pixels per metre

        x_m = (C - ox) / scale
        y_m = (oy - R) / scale

        range_m = np.sqrt(x_m**2 + y_m**2)
        brg_d   = np.degrees(np.arctan2(x_m, y_m))

        # Fan mask — inside the arc and angular limits
        mask = (
            (range_m > ping.range_resolution * 2) &
            (range_m < max_range * 0.998)          &
            (brg_d   >= brg_min)                   &
            (brg_d   <= brg_max)
        )

        ri = np.clip(
            (range_m / ping.range_resolution).astype(np.int32),
            0, ping.n_ranges - 1)

        brg_norm = (brg_d - brg_min) / max(brg_max - brg_min, 1e-6)
        bi = np.clip(
            (brg_norm * (ping.n_beams - 1)).astype(np.int32),
            0, ping.n_beams - 1)

        flat_mask      = mask.ravel()
        self._ri       = ri.ravel()[flat_mask]
        self._bi       = bi.ravel()[flat_mask]
        self._flat_mask = flat_mask
        self._cfg = (ping.n_ranges, ping.n_beams,
                     ping.range_resolution, brg_min, brg_max)

    # ── Render one ping → RGB numpy array ─────────────────────────────────
    def render(self, ping: SonarPing) -> np.ndarray:
        cfg = (ping.n_ranges, ping.n_beams,
               ping.range_resolution,
               float(ping.bearings_deg[0]),
               float(ping.bearings_deg[-1]))
        if cfg != self._cfg:
            self._build_lut(ping)

        img = ping.image   # (n_ranges, n_beams) float32 [0..1]

        # ── Proper min..max contrast stretch (ViewPoint "auto-gain") ──────
        # Only consider non-zero pixels so dark background doesn't flatten image
        nonzero = img[img > 0.0]
        if nonzero.size > 0:
            img_min = float(nonzero.min())
            img_max = float(img.max())
        else:
            img_min, img_max = 0.0, 1.0

        if img_max > img_min:
            stretched = np.clip((img - img_min) / (img_max - img_min), 0.0, 1.0)
        else:
            stretched = img

        # ── Sample + palette-map in-fan pixels ────────────────────────────
        raw          = stretched[self._ri, self._bi]
        intensity_u8 = (raw * 255.0).astype(np.uint8)

        canvas = np.zeros((self.out_h * self.out_w, 3), dtype=np.uint8)
        canvas[self._flat_mask] = PALETTE[intensity_u8]
        return canvas.reshape(self.out_h, self.out_w, 3)


# ─────────────────────────────────────────────────────────────────────────────
class SonarNode(Node):

    def __init__(self):
        super().__init__('oculus_sonar_node')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('sonar_ip',           '192.168.2.6')
        self.declare_parameter('sonar_mode',          1)
        self.declare_parameter('range_m',             1.0)
        self.declare_parameter('gain',                50.0)
        self.declare_parameter('speed_of_sound',      1500.0)
        self.declare_parameter('salinity',            0.0)
        self.declare_parameter('intensity_threshold', 0.01)   # lowered: data max=0.10
        self.declare_parameter('frame_id',           'sonar_link')
        self.declare_parameter('fan_width',           800)
        self.declare_parameter('fan_height',          700)

        ip          = self.get_parameter('sonar_ip').value
        self._thr   = float(self.get_parameter('intensity_threshold').value)
        self._frame = self.get_parameter('frame_id').value
        fw          = int(self.get_parameter('fan_width').value)
        fh          = int(self.get_parameter('fan_height').value)

        self._renderer = FanRenderer(fw, fh)

        # ── Publishers ────────────────────────────────────────────────────
        self._pub_fan = self.create_publisher(Image,       '/sonar/image_fan',  5)
        self._pub_pc  = self.create_publisher(PointCloud2, '/sonar/pointcloud', 10)
        self._pub_ls  = self.create_publisher(LaserScan,   '/sonar/scan',       10)

        # ── Render queue — decouples sonar thread from ROS publish thread ─
        # maxsize=1: always show latest ping, drop old ones (no lag buildup)
        self._q = queue.Queue(maxsize=1)
        self._render_thread = threading.Thread(
            target=self._render_loop, daemon=True)
        self._render_thread.start()

        # ── Sonar driver ──────────────────────────────────────────────────
        self._driver = OculusDriver(
            host           = ip,
            mode           = int(self.get_parameter('sonar_mode').value),
            range_m        = float(self.get_parameter('range_m').value),
            gain           = float(self.get_parameter('gain').value),
            speed_of_sound = float(self.get_parameter('speed_of_sound').value),
            salinity       = float(self.get_parameter('salinity').value),
        )
        self._driver.start(self._on_ping)
        self.get_logger().info(
            f"Sonar node started → {ip}  fan={fw}×{fh}  thr={self._thr}")

    # ── Called from sonar TCP thread — just enqueue, never block ──────────
    def _on_ping(self, ping: SonarPing):
        try:
            self._q.put_nowait(ping)   # drop if queue full (keeps latest)
        except queue.Full:
            try:
                self._q.get_nowait()   # discard old ping
                self._q.put_nowait(ping)
            except queue.Empty:
                pass

    # ── Render loop — runs in its own thread, publishes to ROS ────────────
    def _render_loop(self):
        while rclpy.ok():
            try:
                ping = self._q.get(timeout=1.0)
            except queue.Empty:
                continue
            self._process_and_publish(ping)

    def _process_and_publish(self, ping: SonarPing):
        now = self.get_clock().now().to_msg()
        hdr = Header()
        hdr.stamp    = now
        hdr.frame_id = self._frame

        img = ping.image   # (n_ranges, n_beams) float32

        # ── Auto threshold: use % of actual data range ─────────────────
        data_max = float(img.max())
        # Dynamic threshold = 10% of actual max (handles weak sonar returns)
        dyn_thr = max(self._thr, data_max * 0.10)

        # ══ 1) Fan image (ViewPoint style) ═══════════════════════════════
        fan_rgb        = self._renderer.render(ping)
        fh, fw         = fan_rgb.shape[:2]
        fan_msg        = Image()
        fan_msg.header = hdr
        fan_msg.height = fh
        fan_msg.width  = fw
        fan_msg.encoding = 'rgb8'
        fan_msg.step   = fw * 3
        fan_msg.data   = fan_rgb.tobytes()
        self._pub_fan.publish(fan_msg)

        # ══ 2) LaserScan — first return per beam exceeding threshold ══════
        brg_rad = np.deg2rad(ping.bearings_deg)
        strong  = img > dyn_thr
        has_ret = strong.any(axis=0)                           # (n_beams,)
        first_i = np.argmax(strong, axis=0)                    # (n_beams,)
        beam_idx = np.arange(ping.n_beams)

        hit_rng = np.where(
            has_ret,
            first_i * ping.range_resolution,
            0.0
        ).astype(np.float32)

        hit_int = np.where(
            has_ret,
            img[first_i, beam_idx],
            0.0
        ).astype(np.float32)

        ls               = LaserScan()
        ls.header        = hdr
        ls.angle_min     = float(brg_rad[0])
        ls.angle_max     = float(brg_rad[-1])
        ls.angle_increment = float(
            (brg_rad[-1] - brg_rad[0]) / max(ping.n_beams - 1, 1))
        ls.time_increment = 0.0
        ls.scan_time      = 0.1
        ls.range_min      = float(ping.range_resolution * 2)
        ls.range_max      = float(ping.n_ranges * ping.range_resolution * 0.99)
        ls.ranges         = hit_rng.tolist()
        ls.intensities    = hit_int.tolist()
        self._pub_ls.publish(ls)

        # ══ 3) PointCloud2 ════════════════════════════════════════════════
        valid = has_ret
        n     = int(valid.sum())
        if n > 0:
            x_pts = (hit_rng * np.sin(brg_rad))[valid]
            y_pts = (hit_rng * np.cos(brg_rad))[valid]
            i_pts = hit_int[valid]

            data = np.zeros((n, 4), dtype=np.float32)
            data[:, 0] = x_pts
            data[:, 1] = y_pts
            # z stays 0 (2D)
            data[:, 3] = i_pts

            fields = [
                PointField(name='x',         offset=0,  datatype=PointField.FLOAT32, count=1),
                PointField(name='y',         offset=4,  datatype=PointField.FLOAT32, count=1),
                PointField(name='z',         offset=8,  datatype=PointField.FLOAT32, count=1),
                PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1),
            ]
            pc              = PointCloud2()
            pc.header       = hdr
            pc.height       = 1
            pc.width        = n
            pc.fields       = fields
            pc.is_bigendian = False
            pc.point_step   = 16
            pc.row_step     = 16 * n
            pc.is_dense     = True
            pc.data         = data.tobytes()
            self._pub_pc.publish(pc)

        self.get_logger().info(
            f"Ping {ping.ping_id}: {n}/{ping.n_beams} hits  "
            f"max={img.max():.4f}  dyn_thr={dyn_thr:.4f}  "
            f"T={ping.temperature:.1f}C")

    def destroy_node(self):
        self._driver.stop()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = SonarNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
