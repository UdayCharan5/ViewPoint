#!/usr/bin/env python3
import socket, struct, numpy as np, threading, time
from dataclasses import dataclass
from typing import Optional, Callable

OCULUS_CHECK_ID        = 0x4f53
MSG_SIMPLE_FIRE        = 0x15
MSG_SIMPLE_PING_RESULT = 0x23
MSG_LOG                = 0x80
DEFAULT_PORT           = 52100
DATA_SIZE_8BIT         = 0
PING_RATE_NORMAL       = 0x00

HEADER_FMT     = '<HHHHHIH'
FIRE_BODY_FMT  = '<BBBBBddddIIIIIIIII'
HEADER_SIZE    = struct.calcsize(HEADER_FMT)   # 16
FIRE_BODY_SIZE = struct.calcsize(FIRE_BODY_FMT) # 73

@dataclass
class SonarPing:
    ping_id: int
    timestamp: float
    frequency: float
    temperature: float
    pressure: float
    heading: float
    pitch: float
    roll: float
    speed_of_sound: float
    range_resolution: float
    n_ranges: int
    n_beams: int
    bearings_deg: np.ndarray
    image: np.ndarray

    def to_pointcloud(self, intensity_threshold=0.05):
        brg_rad = np.deg2rad(self.bearings_deg)
        ranges  = np.arange(self.n_ranges) * self.range_resolution
        R, B    = np.meshgrid(ranges, brg_rad, indexing='ij')
        x = R * np.sin(B)
        y = R * np.cos(B)
        mask   = self.image > intensity_threshold
        pts    = np.column_stack([x[mask], y[mask]])
        intens = self.image[mask]
        t      = np.full(pts.shape[0], self.timestamp)
        return pts, intens, t


class OculusDriver:
    def __init__(self, host, port=DEFAULT_PORT, mode=1,
                 range_m=1.0, gain=50.0, speed_of_sound=1500.0, salinity=0.0):
        self.host, self.port = host, port
        self.mode, self.range_m = mode, range_m
        self.gain, self.sos, self.salinity = gain, speed_of_sound, salinity
        self._sock    = None
        self._thread  = None
        self._running = False
        self._callback = None
        self._rx_buf  = bytearray()

    def start(self, callback):
        self._callback = callback
        self._running  = True
        self._thread   = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._sock:
            self._sock.close()

    def _build_fire_message(self):
        header = struct.pack(HEADER_FMT,
            OCULUS_CHECK_ID, 0, 0, MSG_SIMPLE_FIRE, 2, FIRE_BODY_SIZE, 0)
        body = struct.pack(FIRE_BODY_FMT,
            self.mode, PING_RATE_NORMAL, 0, 127, 0x19,
            self.range_m, self.gain, self.sos, self.salinity,
            0, 0, 0, 0, 0, 0, 0, 0, 0)
        return header + body

    def _run(self):
        while self._running:
            try:
                self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._sock.settimeout(5.0)
                self._sock.connect((self.host, self.port))
                print(f"[OculusDriver] Connected to {self.host}:{self.port}")
                self._sock.sendall(self._build_fire_message())
                self._rx_buf.clear()
                while self._running:
                    chunk = self._sock.recv(65536)
                    if not chunk:
                        break
                    self._rx_buf.extend(chunk)
                    self._process_buffer()
            except Exception as e:
                print(f"[OculusDriver] Error: {e}, reconnecting in 2s...")
                time.sleep(2)
            finally:
                if self._sock:
                    self._sock.close()

    def _process_buffer(self):
        while len(self._rx_buf) >= HEADER_SIZE:
            # Find sync word 0x4f53 (bytes: 53 4f)
            sync_pos = -1
            for i in range(len(self._rx_buf) - 1):
                if self._rx_buf[i] == 0x53 and self._rx_buf[i+1] == 0x4f:
                    sync_pos = i
                    break
            if sync_pos < 0:
                self._rx_buf.clear(); return
            if sync_pos > 0:
                del self._rx_buf[:sync_pos]
            if len(self._rx_buf) < HEADER_SIZE:
                return

            _, _, _, msg_id, _, payload_size, _ = struct.unpack_from(HEADER_FMT, self._rx_buf, 0)
            total_size = HEADER_SIZE + payload_size
            if len(self._rx_buf) < total_size:
                return  # wait for more data

            pkt = bytes(self._rx_buf[:total_size])
            del self._rx_buf[:total_size]

            if msg_id == MSG_SIMPLE_PING_RESULT:
                ping = self._parse_ping(pkt)
                if ping and self._callback:
                    self._callback(ping)
            # MSG_LOG (0x80) silently ignored

    def _parse_ping(self, pkt):
        try:
            # Payload starts after outer header
            # Then: embedded fire body (FIRE_BODY_SIZE bytes)
            # Then: ping result fields
            off = HEADER_SIZE + FIRE_BODY_SIZE

            ping_id, status          = struct.unpack_from('<II',  pkt, off); off += 8
            freq, temp, pressure     = struct.unpack_from('<ddd', pkt, off); off += 24
            heading, pitch, roll     = struct.unpack_from('<ddd', pkt, off); off += 24
            sos, ping_start_time     = struct.unpack_from('<dd',  pkt, off); off += 16
            data_size,               = struct.unpack_from('<B',   pkt, off); off += 1
            range_res,               = struct.unpack_from('<d',   pkt, off); off += 8
            n_ranges, n_beams        = struct.unpack_from('<HH',  pkt, off); off += 4
            _                        = struct.unpack_from('<IIII',pkt, off); off += 16  # spares
            image_offset, image_size, _ = struct.unpack_from('<III', pkt, off); off += 12

            # Bearings: int16[n_beams] immediately after header fields
            brg_raw      = struct.unpack_from(f'<{n_beams}h', pkt, off)
            bearings_deg = np.array(brg_raw, dtype=np.float32) * 0.01

            # Image: at image_offset from start of packet
            img_start = image_offset
            img_end   = img_start + image_size
            if data_size == DATA_SIZE_8BIT:
                raw   = np.frombuffer(pkt[img_start:img_end], dtype=np.uint8)
                image = raw.reshape((n_ranges, n_beams)).astype(np.float32) / 255.0
            else:
                raw   = np.frombuffer(pkt[img_start:img_end], dtype=np.uint16)
                image = raw.reshape((n_ranges, n_beams)).astype(np.float32) / 65535.0

            return SonarPing(ping_id, ping_start_time, freq, temp, pressure,
                             heading, pitch, roll, sos, range_res,
                             n_ranges, n_beams, bearings_deg, image)
        except Exception as e:
            print(f"[OculusDriver] Parse error: {e}")
            return None
