#!/usr/bin/env python3
"""
Oculus M750d ROS2 node — ViewPoint-style fan image.
Fixes:
  1) Range change works in real-time (re-fires sonar on param change)
  2) Full cone visible — apex padding + correct canvas sizing
  3) Frequency / ping-rate control exposed as parameter
  4) Lag-free: render thread + drop-oldest queue
  5) Proper min..max contrast stretch
"""
import rclpy
from rclpy.node import Node
import numpy as np
import threading
import queue

from sensor_msgs.msg import PointCloud2, PointField, LaserScan, Image
from std_msgs.msg import Header
from oculus_driver.oculus_driver import OculusDriver, SonarPing

# ── Oculus ViewPoint default palette (warm gold, 256 entries) ────────────────
_PAL_RAW = [
    (2,1,0),(4,2,0),(6,4,0),(8,5,0),(10,6,0),(12,7,0),(14,9,0),(15,10,0),(17,11,0),(19,12,0),(21,14,0),(23,15,0),(25,16,0),(27,17,0),(29,18,0),(31,20,0),
    (33,21,0),(35,22,0),(37,23,0),(39,25,0),(41,26,0),(43,27,0),(45,28,0),(46,29,0),(48,31,0),(50,32,0),(52,33,0),(54,34,0),(56,36,0),(58,37,0),(60,38,0),(62,39,0),
    (64,41,0),(66,42,0),(68,43,0),(70,44,0),(72,45,0),(74,47,0),(76,48,0),(77,49,0),(79,50,0),(81,52,0),(83,53,0),(85,54,0),(87,55,0),(89,57,0),(91,58,0),(93,59,0),
    (95,60,0),(97,61,0),(99,63,0),(101,64,0),(103,65,0),(105,66,0),(107,68,0),(108,69,0),(110,70,0),(112,71,0),(114,72,0),(116,74,0),(118,75,0),(120,76,0),(122,77,0),(124,79,0),
    (126,80,0),(128,81,0),(130,82,0),(131,83,0),(133,85,0),(135,86,0),(137,87,0),(139,88,0),(141,89,0),(143,91,0),(145,92,0),(146,93,0),(148,94,0),(150,95,0),(152,97,0),(154,98,0),
    (156,99,0),(158,100,0),(160,101,0),(161,103,0),(163,104,0),(165,105,0),(167,106,0),(169,107,0),(171,109,0),(173,110,0),(175,111,0),(176,112,0),(178,113,0),(180,115,0),(182,116,0),(184,117,0),
    (186,118,0),(188,119,0),(190,120,0),(191,122,0),(193,123,0),(195,124,0),(197,125,0),(199,126,0),(201,128,0),(203,129,0),(205,130,0),(206,131,0),(208,132,0),(210,134,0),(212,135,0),(214,136,0),
    (216,137,0),(218,138,0),(220,140,0),(221,141,0),(223,142,0),(225,143,0),(227,144,0),(229,146,0),(231,147,0),(233,148,0),(235,149,0),(236,150,0),(238,152,0),(240,153,0),(242,154,0),(242,157,6),
    (242,157,6),(243,159,12),(243,162,19),(244,165,25),(244,167,31),(244,170,37),(245,173,43),(245,176,49),(246,178,56),(246,181,62),(246,184,68),(247,186,74),(247,189,80),(248,192,86),(248,194,93),(248,197,99),
    (249,200,105),(249,203,111),(249,205,117),(250,208,124),(250,211,130),(251,213,136),(251,216,142),(251,219,148),(252,221,154),(252,224,161),(253,227,167),(253,229,173),(253,232,179),(254,235,185),(254,238,192),(255,240,198),
    (255,243,204),(255,243,205),(255,243,205),(255,243,206),(255,244,206),(255,244,207),(255,244,208),(255,244,208),(255,244,209),(255,244,209),(255,244,210),(255,244,210),(255,245,211),(255,245,212),(255,245,212),(255,245,213),
    (255,245,213),(255,245,214),(255,245,215),(255,245,215),(255,246,216),(255,246,216),(255,246,217),(255,246,218),(255,246,218),(255,246,219),(255,246,219),(255,247,220),(255,247,221),(255,247,221),(255,247,222),(255,247,222),
    (255,247,223),(255,247,223),(255,247,224),(255,248,224),(255,248,225),(255,248,225),(255,248,226),(255,248,226),(255,248,227),(255,248,227),(255,248,228),(255,249,228),(255,249,229),(255,249,230),(255,249,230),(255,249,231),
    (255,249,231),(255,249,232),(255,249,232),(255,250,233),(255,250,233),(255,250,234),(255,250,234),(255,250,235),(255,250,235),(255,250,236),(255,250,236),(255,251,237),(255,251,237),(255,251,238),(255,251,238),(255,251,239),
    (255,251,239),(255,251,240),(255,251,240),(255,252,241),(255,252,241),(255,252,242),(255,252,243),(255,252,243),(255,252,244),(255,252,244),(255,252,245),(255,253,245),(255,253,246),(255,253,246),(255,253,247),(255,253,247),
    (255,253,248),(255,253,248),(255,253,249),(255,254,249),(255,254,250),(255,254,250),(255,254,251),(255,254,251),(255,254,252),(255,254,252),(255,254,253),(255,255,253),(255,255,254),(255,255,254),(255,255,255),(255,255,255),
]
PALETTE = np.array(_PAL_RAW, dtype=np.uint8)  # (256, 3)

# Ping rate codes from Oculus.h
PING_RATES = {
    'standby':  0x05,   # 0 Hz  (pause)
    'lowest':   0x04,   # ~2 Hz
    'low':      0x03,   # ~5 Hz
    'normal':   0x00,   # ~10 Hz
    'high':     0x01,   # ~15 Hz
    'highest':  0x02,   # ~40 Hz
}


# ─────────────────────────────────────────────────────────────────────────────
class FanRenderer:
    """
    Pre-builds pixel→(range_idx, beam_idx) LUT once per sonar config.
    Canvas is LARGER than the fan so the full cone always fits:
      - apex_pad rows added below apex so bottom of cone is not clipped
      - left/right pad columns so wide-angle fans don't clip edges
    """

    # Extra space around the fan (fraction of image dimension)
    APEX_PAD_FRAC  = 0.08   # 8% padding below apex  → shows bottom arc
    SIDE_PAD_FRAC  = 0.04   # 4% padding each side   → shows outer edges

    def __init__(self, fan_w: int, fan_h: int):
        # fan_w / fan_h = the requested fan canvas size
        # We add padding internally so the full cone is always visible
        self.fan_w = fan_w
        self.fan_h = fan_h
        self._cfg  = None
        self._ri   = None
        self._bi   = None
        self._flat_mask = None
        self._canvas_w  = None
        self._canvas_h  = None

    def _build_lut(self, ping: SonarPing):
        brg_min   = float(ping.bearings_deg[0])
        brg_max   = float(ping.bearings_deg[-1])
        max_range = ping.n_ranges * ping.range_resolution

        # ── Canvas with padding ───────────────────────────────────────────
        # We compute scale so that the arc fits in fan_h rows,
        # then add apex_pad rows below and side_pad cols on each side.
        scale = self.fan_h / max_range            # pixels per metre (base)

        apex_pad = int(self.fan_h * self.APEX_PAD_FRAC)   # rows below apex
        side_pad = int(self.fan_w * self.SIDE_PAD_FRAC)   # cols each side

        W = self.fan_w + 2 * side_pad
        H = self.fan_h + apex_pad

        self._canvas_w = W
        self._canvas_h = H

        cols = np.arange(W, dtype=np.float32)
        rows = np.arange(H, dtype=np.float32)
        C, R = np.meshgrid(cols, rows)   # (H, W)

        # Apex is at (W/2, H-apex_pad) — leaves apex_pad rows below it
        ox = W / 2.0
        oy = H - apex_pad            # apex row position

        x_m = (C - ox) / scale
        y_m = (oy - R) / scale       # positive = upward (forward)

        range_m = np.sqrt(x_m**2 + y_m**2)
        brg_d   = np.degrees(np.arctan2(x_m, y_m))

        # ── Fan mask — only pixels inside the cone ────────────────────────
        mask = (
            (y_m      >= 0.0)                        &   # above apex
            (range_m  > ping.range_resolution * 2)   &   # skip dead zone
            (range_m  < max_range * 0.999)            &   # inside max range
            (brg_d    >= brg_min)                     &   # left edge
            (brg_d    <= brg_max)                         # right edge
        )

        ri = np.clip(
            (range_m / ping.range_resolution).astype(np.int32),
            0, ping.n_ranges - 1)

        brg_span = max(brg_max - brg_min, 1e-6)
        brg_norm = (brg_d - brg_min) / brg_span
        bi = np.clip(
            (brg_norm * (ping.n_beams - 1)).astype(np.int32),
            0, ping.n_beams - 1)

        flat_mask       = mask.ravel()
        self._ri        = ri.ravel()[flat_mask]
        self._bi        = bi.ravel()[flat_mask]
        self._flat_mask = flat_mask
        self._cfg = (ping.n_ranges, ping.n_beams,
                     ping.range_resolution, brg_min, brg_max)

    def render(self, ping: SonarPing) -> np.ndarray:
        cfg = (ping.n_ranges, ping.n_beams,
               ping.range_resolution,
               float(ping.bearings_deg[0]),
               float(ping.bearings_deg[-1]))
        if cfg != self._cfg:
            self._build_lut(ping)

        img = ping.image   # (n_ranges, n_beams) float32 [0..1]

        # ── Proper min..max contrast stretch ──────────────────────────────
        nonzero = img[img > 0.0]
        if nonzero.size > 0:
            img_min = float(np.percentile(nonzero, 2))    # 2nd percentile: ignore tiny noise floor
            img_max = float(np.percentile(nonzero, 99))   # 99th: ignore single hot pixels
        else:
            img_min, img_max = 0.0, 1.0

        if img_max > img_min + 1e-6:
            stretched = np.clip((img - img_min) / (img_max - img_min), 0.0, 1.0)
        else:
            stretched = np.zeros_like(img)

        # ── Sample palette for in-fan pixels ─────────────────────────────
        raw          = stretched[self._ri, self._bi]
        intensity_u8 = (raw * 255.0).astype(np.uint8)

        # Background = black (index 0 in palette = near-black)
        canvas = np.zeros((self._canvas_h * self._canvas_w, 3), dtype=np.uint8)
        canvas[self._flat_mask] = PALETTE[intensity_u8]
        return canvas.reshape(self._canvas_h, self._canvas_w, 3)


# ─────────────────────────────────────────────────────────────────────────────
class SonarNode(Node):

    def __init__(self):
        super().__init__('oculus_sonar_node')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('sonar_ip',           '192.168.2.6')
        self.declare_parameter('sonar_mode',          1)          # 1=750kHz  2=1.2MHz
        self.declare_parameter('range_m',             1.0)       # metres
        self.declare_parameter('gain',                50.0)       # percent
        self.declare_parameter('speed_of_sound',      1500.0)     # m/s
        self.declare_parameter('salinity',            0.0)        # 0=fresh  35=salt
        self.declare_parameter('ping_rate',          'normal')    # standby/lowest/low/normal/high/highest
        self.declare_parameter('intensity_threshold', 0.01)       # min fraction to count as a return
        self.declare_parameter('frame_id',           'sonar_link')
        self.declare_parameter('fan_width',           800)
        self.declare_parameter('fan_height',          700)

        ip          = self.get_parameter('sonar_ip').value
        self._thr   = float(self.get_parameter('intensity_threshold').value)
        self._frame = self.get_parameter('frame_id').value
        fw          = int(self.get_parameter('fan_width').value)
        fh          = int(self.get_parameter('fan_height').value)

        ping_rate_str = self.get_parameter('ping_rate').value
        ping_rate_code = PING_RATES.get(ping_rate_str, PING_RATES['normal'])

        self._renderer = FanRenderer(fw, fh)

        # ── Publishers ────────────────────────────────────────────────────
        self._pub_fan = self.create_publisher(Image,       '/sonar/image_fan',  5)
        self._pub_pc  = self.create_publisher(PointCloud2, '/sonar/pointcloud', 10)
        self._pub_ls  = self.create_publisher(LaserScan,   '/sonar/scan',       10)

        # ── Render queue — drop-oldest so lag never accumulates ───────────
        self._q = queue.Queue(maxsize=1)
        self._render_thread = threading.Thread(
            target=self._render_loop, daemon=True)
        self._render_thread.start()

        # ── Sonar driver ──────────────────────────────────────────────────
        self._driver = OculusDriver(
            host           = ip,
            mode           = int(self.get_parameter('sonar_mode').value),
            range_m        = float(self.get_parameter('range_m').value),
            gain           = float(self.get_parameter('gain').value),
            speed_of_sound = float(self.get_parameter('speed_of_sound').value),
            salinity       = float(self.get_parameter('salinity').value),
            ping_rate      = ping_rate_code,
        )
        self._driver.start(self._on_ping)

        # ── Parameter change callback (range / gain / freq live update) ───
        self.add_on_set_parameters_callback(self._on_param_change)

        self.get_logger().info(
            f"Sonar node started → {ip}  "
            f"range={self.get_parameter('range_m').value}m  "
            f"gain={self.get_parameter('gain').value}%  "
            f"ping_rate={ping_rate_str}  "
            f"fan={fw}×{fh}")

    # ── Live parameter updates ─────────────────────────────────────────────
    def _on_param_change(self, params):
        from rcl_interfaces.msg import SetParametersResult
        for p in params:
            if p.name == 'range_m':
                self._driver.set_range(float(p.value))
                self.get_logger().info(f"Range → {p.value} m")
            elif p.name == 'gain':
                self._driver.set_gain(float(p.value))
                self.get_logger().info(f"Gain → {p.value} %")
            elif p.name == 'ping_rate':
                code = PING_RATES.get(p.value, PING_RATES['normal'])
                self._driver.set_ping_rate(code)
                self.get_logger().info(f"Ping rate → {p.value}")
            elif p.name == 'intensity_threshold':
                self._thr = float(p.value)
        return SetParametersResult(successful=True)

    # ── Called from sonar TCP thread ──────────────────────────────────────
    def _on_ping(self, ping: SonarPing):
        try:
            self._q.put_nowait(ping)
        except queue.Full:
            try:
                self._q.get_nowait()
                self._q.put_nowait(ping)
            except queue.Empty:
                pass

    # ── Render loop — separate thread ─────────────────────────────────────
    def _render_loop(self):
        while rclpy.ok():
            try:
                ping = self._q.get(timeout=1.0)
            except queue.Empty:
                continue
            self._process_and_publish(ping)

    def _process_and_publish(self, ping: SonarPing):
        now = self.get_clock().now().to_msg()
        hdr = Header()
        hdr.stamp    = now
        hdr.frame_id = self._frame

        img = ping.image   # (n_ranges, n_beams) float32

        # Dynamic threshold: 10% of actual ping max
        data_max = float(img.max())
        dyn_thr  = max(self._thr, data_max * 0.10)

        # ══ 1) Fan image ═════════════════════════════════════════════════
        fan_rgb        = self._renderer.render(ping)
        fh, fw         = fan_rgb.shape[:2]
        fan_msg        = Image()
        fan_msg.header   = hdr
        fan_msg.height   = fh
        fan_msg.width    = fw
        fan_msg.encoding = 'rgb8'
        fan_msg.step     = fw * 3
        fan_msg.data     = fan_rgb.tobytes()
        self._pub_fan.publish(fan_msg)

        # ══ 2) LaserScan — first strong return per beam ═══════════════════
        brg_rad = np.deg2rad(ping.bearings_deg)
        strong  = img > dyn_thr
        has_ret = strong.any(axis=0)
        first_i = np.argmax(strong, axis=0)
        beam_idx = np.arange(ping.n_beams)

        hit_rng = np.where(
            has_ret, first_i * ping.range_resolution, 0.0
        ).astype(np.float32)
        hit_int = np.where(
            has_ret, img[first_i, beam_idx], 0.0
        ).astype(np.float32)

        ls               = LaserScan()
        ls.header        = hdr
        ls.angle_min     = float(brg_rad[0])
        ls.angle_max     = float(brg_rad[-1])
        ls.angle_increment = float(
            (brg_rad[-1] - brg_rad[0]) / max(ping.n_beams - 1, 1))
        ls.time_increment = 0.0
        ls.scan_time      = 0.1
        ls.range_min      = float(ping.range_resolution * 2)
        ls.range_max      = float(ping.n_ranges * ping.range_resolution * 0.99)
        ls.ranges         = hit_rng.tolist()
        ls.intensities    = hit_int.tolist()
        self._pub_ls.publish(ls)

        # ══ 3) PointCloud2 ════════════════════════════════════════════════
        valid = has_ret
        n     = int(valid.sum())
        if n > 0:
            x_pts = (hit_rng * np.sin(brg_rad))[valid]
            y_pts = (hit_rng * np.cos(brg_rad))[valid]
            i_pts = hit_int[valid]

            data = np.zeros((n, 4), dtype=np.float32)
            data[:, 0] = x_pts
            data[:, 1] = y_pts
            data[:, 3] = i_pts

            fields = [
                PointField(name='x',         offset=0,  datatype=PointField.FLOAT32, count=1),
                PointField(name='y',         offset=4,  datatype=PointField.FLOAT32, count=1),
                PointField(name='z',         offset=8,  datatype=PointField.FLOAT32, count=1),
                PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1),
            ]
            pc              = PointCloud2()
            pc.header       = hdr
            pc.height       = 1
            pc.width        = n
            pc.fields       = fields
            pc.is_bigendian = False
            pc.point_step   = 16
            pc.row_step     = 16 * n
            pc.is_dense     = True
            pc.data         = data.tobytes()
            self._pub_pc.publish(pc)

        self.get_logger().info(
            f"Ping {ping.ping_id}: {n}/{ping.n_beams} hits  "
            f"max={img.max():.4f}  dyn_thr={dyn_thr:.4f}  "
            f"range_res={ping.range_resolution:.4f}m  "
            f"T={ping.temperature:.1f}C")

    def destroy_node(self):
        self._driver.stop()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = SonarNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
